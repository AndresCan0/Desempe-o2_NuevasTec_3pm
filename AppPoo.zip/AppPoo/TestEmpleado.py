from Empleado import Empleado

empleado1 = Empleado (id=None,
                       nombre=None,
                       apellido=None,
                       correo=None,
                       contrasena=None,
                       cargo=None,
                       salario=None)

empleado1.registrar()
empleado1.ver_registro()

empleado1.iniciar_negocio_empleado(empleado1.iniciar_sesion, empleado1.ver_registro)